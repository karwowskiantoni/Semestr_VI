package classificator.model.internal;

public record Result(Label correctLabel, Label predictedLabel) {}
