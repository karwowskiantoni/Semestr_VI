package classificator.model.internal;

public record Text(Label label, Vector vector) { }
